package com.example.postgres_demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.postgres_demo.exception.ResourceNotFoundException;
import com.example.postgres_demo.model.Question;
import com.example.postgres_demo.repository.QuestionRepository;

@RestController
public class QuestionController {
	@Autowired
	private QuestionRepository questionRepository;
	@GetMapping("/questions/{questionId}")
	public List<Question> getQuestions(@PathVariable(value="questionId") Long questionId){
		return questionRepository.findByQuestionId(questionId);
	}
	@PostMapping("/questions")
	public Question updateQuestion(@Valid @RequestBody Question question) {
		return questionRepository.save(question);
	}
}

