package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Question;
import com.example.demo.repository.QuestionRepository;

@RestController
public class QuestionController {
	@Autowired
	private QuestionRepository questionRepository;
	@GetMapping("/home")
	public String home() {
		return "Welcome Buddy!";
	}
	@GetMapping("/questions")
	public List<Question> getAllEmployee() throws ResourceNotFoundException{
		return questionRepository.findAll();
	}
	@GetMapping("/question/{questionId}")
	public ResponseEntity<Question> getQuestionById(@PathVariable(value="questionId") Long questionId) throws ResourceNotFoundException{
		Question question=questionRepository.findById(questionId).orElseThrow(()-> new ResourceNotFoundException("Questoin not found for this id "+questionId));
		return ResponseEntity.ok().body(question);
	}
	@PostMapping("/question")
	public Question createEmployee(@RequestBody Question question){
		return questionRepository.save(question);
	}
	@PutMapping("/question/{questionId}")
	public ResponseEntity<Question> updateEmployeeById(@PathVariable(value="questionId") Long questionId,@RequestBody Question questionDetails) throws ResourceNotFoundException{
		Question question=questionRepository.findById(questionId).orElseThrow(()-> new ResourceNotFoundException("Question not found for this id"+questionId));
		question.setDescription(questionDetails.getDescription());
		question.setText(questionDetails.getText());
		questionRepository.save(question);
		return ResponseEntity.ok().body(question);
	}
	@DeleteMapping("/question/{questionId}")
	public Map<String,Boolean> deleteQuestion(@PathVariable(value="questionId") Long questionId) throws ResourceNotFoundException{
		Question question=questionRepository.findById(questionId).orElseThrow(()->new ResourceNotFoundException("Question not found for this id "+questionId));
		questionRepository.delete(question);
		Map<String,Boolean> response=new HashMap();
		response.put("deleted",true);
		return response;
	}
}
