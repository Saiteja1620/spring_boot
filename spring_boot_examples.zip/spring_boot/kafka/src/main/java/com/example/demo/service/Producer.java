package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class Producer {
	
	public String topic="myTopic";
	@Autowired
	public KafkaTemplate<String, String> kafkaTemp;
	public void publish(String message){
		System.out.println("publishing to topic"+topic);
		kafkaTemp.send(topic, message);
	}
}
