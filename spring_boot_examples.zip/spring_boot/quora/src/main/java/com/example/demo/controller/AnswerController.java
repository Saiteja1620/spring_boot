package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.exception.Resource;
import com.example.demo.model.Answer;
import com.example.demo.model.Question;
import com.example.demo.repository.AnwerRepo;
import com.example.demo.repository.QuestionRepo;

@RestController
public class AnswerController {
	@Autowired
	private QuestionRepo questionRepo;
	@Autowired
	private AnwerRepo answerRepo;
	@GetMapping("/question/{questionId}/answer")
	public List<Answer> findByQuestionId(@PathVariable(value="questionId") Long questionId) throws Resource{
			return answerRepo.findAll();
	}
	@PostMapping("/question/{questionId}/answer")
	public ResponseEntity<Answer> createAnswer(@PathVariable(value="questionId") Long questionId,@RequestBody Answer answer) throws Resource{
		Question q=questionRepo.findById(questionId).orElseThrow(()-> new Resource("Question not found for this id "+ questionId));
		answerRepo.save(answer);
		return ResponseEntity.ok().body(answer);
	}
	@PutMapping("/question/{questionId}/answer/{answerId}")
	public Answer updateAnswer(@PathVariable(value="questionId") Long questionId,@PathVariable(value="answerId") Long answerId,@RequestBody Answer answer) throws Resource{
		Question q=questionRepo.findById(questionId).orElseThrow(()-> new Resource("Question not found for this id "+ questionId));
		Answer a=answerRepo.findById(answerId).orElseThrow(()->new Resource("Answer not found for this id "+ answerId));
		a.setQuestion(answer.getQuestion());
		a.setAnswer(answer.getAnswer());
		return answerRepo.save(a);
	}
	@DeleteMapping("/question/{questionId}/answer/{answerId}")
	public ResponseEntity<Answer> deleteAnswer(@PathVariable(value="questionId") Long questionId , @PathVariable(value="answerId") Long answerId) throws Resource{
		Question q=questionRepo.findById(questionId).orElseThrow(()-> new Resource("Question not found for this id "+ questionId));
		Answer a=answerRepo.findById(answerId).orElseThrow(()->new Resource("Answer not found for this id "+ answerId));
		answerRepo.delete(a);
		return ResponseEntity.ok().body(a);
	}
	
}
