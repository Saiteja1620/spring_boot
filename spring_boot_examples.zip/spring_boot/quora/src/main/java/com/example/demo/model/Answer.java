package com.example.demo.model;

import javax.persistence.*;

@Entity
@Table(name="ans")
public class Answer {
	@Id
	@GeneratedValue(generator="answer_generator")
	private Long id;
	@Column(name="answer")
	private String answer;
	@ManyToOne()
	@JoinColumn(name="question_id")
	private Question question;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
}
