package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.exception.Resource;
import com.example.demo.model.Question;
import com.example.demo.repository.QuestionRepo;

@RestController
public class QuestionController {
	@Autowired
	private QuestionRepo questionRepo;
	@GetMapping("/questions")
	public List<Question> getAllQuestions(){
		return questionRepo.findAll();
	}
	@GetMapping("/question/{questionId}")
	public ResponseEntity<Question> getById(@PathVariable(value="questionId") Long questionId) throws Resource{
		Question question=questionRepo.findById(questionId).orElseThrow(()-> new Resource("Question not found for this id "+ questionId));
		return ResponseEntity.ok().body(question);
	}
	@PostMapping("/question")
	public Question createQuestion(@RequestBody Question question) {
		return questionRepo.save(question);
	}
	@PutMapping("/question/{questionId}")
	public ResponseEntity<Question> updateQuestionById(@PathVariable(value="questionId") Long questionId,@RequestBody Question question) throws Resource{
		Question q=questionRepo.findById(questionId).orElseThrow(()-> new Resource("Question not found for this id" + questionId));
		q.setQuestion(question.getQuestion());
		questionRepo.save(q);
		return ResponseEntity.ok().body(q);
	}
	@DeleteMapping("/question/{questionId}")
	public ResponseEntity<Question> deleteQuestion(@PathVariable(value="questionId") Long questionId) throws Resource{
		Question q= questionRepo.findById(questionId).orElseThrow(()-> new Resource("Question not found for this id "+ questionId));
		questionRepo.delete(q);
		return ResponseEntity.ok().body(q);
	}
	
}
