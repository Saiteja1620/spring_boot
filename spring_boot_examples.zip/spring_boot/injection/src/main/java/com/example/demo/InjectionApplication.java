package com.example.demo;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class InjectionApplication {
	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(InjectionApplication.class, args);
		Alien a=context.getBean(Alien.class);
		a.setAid(34);
		System.out.println(a.getAid()+"loves 68");
		a.show();
	}

}
