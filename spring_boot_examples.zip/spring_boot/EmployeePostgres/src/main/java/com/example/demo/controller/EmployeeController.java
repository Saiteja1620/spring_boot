package com.example.demo.controller;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Employee;
import com.example.demo.repository.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class EmployeeController {
	@Autowired
	private EmployeeRepository employeerepository;
	//to know whether the controller is working or not
	@RequestMapping("/home")
	public String home() {
		return "Welcome Buddy!";
	}
	
	//fetching all employees
	@GetMapping("/employees")
	public List<Employee> getAllEmployees() {
		return employeerepository.findAll();
	}
	//fetching employee by employeeId
	@GetMapping("/employee/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable(value="id") Long employeeId) throws ResourceNotFoundException{
		Employee employee=employeerepository.findById(employeeId).orElseThrow(()-> new ResourceNotFoundException("Employee not found for this id"+employeeId));
		return ResponseEntity.ok().body(employee);
	}
	
	//save employee
	@PostMapping("/employee")
	public Employee createEmployee(@RequestBody Employee employee) {
		return employeerepository.save(employee);
	}
	
	//updating an employee
	@PutMapping("/employee/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable(value="id") Long employeeId,@RequestBody Employee employeeDetails) throws ResourceNotFoundException{
		Employee employee=employeerepository.findById(employeeId).orElseThrow(()-> new ResourceNotFoundException("Employee not found for this id"+employeeId));
		employee.setEmail(employeeDetails.getEmail());
		employee.setFirstName(employeeDetails.getFirstName());
		employee.setLastName(employeeDetails.getLastName());
		employeerepository.save(employee);
		return ResponseEntity.ok().body(employee);
	}
	//delete employee
	@DeleteMapping("/employee/{id}")
	public Map<String,Boolean> deleteEmployee(@PathVariable(value="id") Long employeeId) throws ResourceNotFoundException{
		Employee employee=employeerepository.findById(employeeId).orElseThrow(()-> new ResourceNotFoundException("Employee not found for this id"+employeeId));
		employeerepository.deleteById(employeeId);
		Map<String,Boolean> response=new HashMap();
		response.put("deleted", true);
		return response;
	}
}
