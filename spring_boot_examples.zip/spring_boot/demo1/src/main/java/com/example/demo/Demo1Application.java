package com.example.demo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Demo1Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(Demo1Application.class, args);
		System.out.println("<|-----------|>>>>>>>>>|||||||Hello world<<<<<<<|------------|>");
		Alien a = context.getBean(Alien.class);
		a.setAid(68);
		System.out.println(a.getAid());
	}
}
