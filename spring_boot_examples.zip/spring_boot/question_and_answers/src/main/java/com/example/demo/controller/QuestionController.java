package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.demo.exception.*;
import com.example.demo.model.Question;
import com.example.demo.repository.QuestionRepository;

@RestController
public class QuestionController {
	@Autowired
	private QuestionRepository questionRepository;
	@GetMapping("/home")
	public String home() {
		return "Welcome BUddy!";
	}
	@GetMapping("/questions")
	public List<Question> getAllQuestions(){
		return questionRepository.findAll();
	}
	@GetMapping("/question/{questionId}")
	public ResponseEntity<Question> getQuestionById(@PathVariable(value="questionId") Long questionId) throws Resouce{
		Question question=questionRepository.findById(questionId).orElseThrow(()-> new Resouce("Question not found for this id "+ questionId));
		return ResponseEntity.ok().body(question);
	}
	@PostMapping("/question")
	public Question createQuesiton(@RequestBody Question question) {
		return questionRepository.save(question);
	}
	@PutMapping("/question/{questionId}")
	public ResponseEntity<Question> updateQuestionById(@PathVariable(value="questionId") Long questionId,@RequestBody Question questionDetails) throws Resouce{
		Question question=questionRepository.findById(questionId).orElseThrow(()-> new Resouce("Question not found for this id "+ questionId));
		question.setDescription(questionDetails.getDescription());
		question.setText(questionDetails.getText());
		questionRepository.save(question);
		return ResponseEntity.ok().body(question);
	}
	@DeleteMapping("/question/{questionId}")
	public Map<String, Boolean> deleteQuestionById(@PathVariable(value="questionId") Long questionId) throws Resouce{
		Question question=questionRepository.findById(questionId).orElseThrow(()-> new Resouce("Question not found for this id"+ questionId));
		questionRepository.delete(question);
		Map<String,Boolean> res=new HashMap();
		res.put("deleted", true);
		return res;
	}
}
