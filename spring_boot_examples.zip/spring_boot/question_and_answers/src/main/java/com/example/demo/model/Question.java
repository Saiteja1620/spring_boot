package com.example.demo.model;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="question_and_answers")
public class Question {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long qid;
	@Column(name="text")
	private String text;
	@Column(name="description")
	private String description;
	@OneToMany()
	private List<Answer> answer;
	public List<Answer> getAnswer() {
		return answer;
	}
	public void setAnswer(List<Answer> answer) {
		this.answer = answer;
	}
	public Long getQid() {
		return qid;
	}
	public void setQid(Long qid) {
		this.qid = qid;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}


}
