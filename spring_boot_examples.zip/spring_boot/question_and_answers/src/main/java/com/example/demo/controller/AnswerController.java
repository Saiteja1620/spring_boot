package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.exception.Resouce;
import com.example.demo.model.Answer;
import com.example.demo.model.Question;
import com.example.demo.repository.AnswerRepository;
import com.example.demo.repository.QuestionRepository;

@RestController
public class AnswerController {
	@Autowired
	private AnswerRepository answerRepository;
	@Autowired
	private QuestionRepository questionRepository;
	@GetMapping("/home_answer")
	public String home() {
		return "Welcome Buddy!";
	}
	@GetMapping("/question/{questionId}/answers")
	public List<Answer> getAnswersByQuestionId(@PathVariable(value="questionId") Long questionId) throws Resouce{
		return answerRepository.findAll();
	}
	@PostMapping("/question/{questionId}/answer")
	public Answer createAnswer(@PathVariable(value="questionId") Long questionId ,@RequestBody Answer answer) throws Resouce{
		Question question=questionRepository.findById(questionId).orElseThrow(()-> new Resouce("Question not found for this id "+ questionId));
		answer.setQuestion(question);
		return answerRepository.save(answer);
	}
	@PutMapping("/question/{questionId}/answer/{answerId}")
	public Answer updateAnswer(@PathVariable(value="questionId") Long questionId,@PathVariable(value="answerId") Long answerId,@RequestBody Answer answer) throws Resouce{
		if(!questionRepository.existsById(questionId)) {
			throw new Resouce("Question not found for this id "+questionId);
		}
		Answer ans=answerRepository.findById(answerId).orElseThrow(()->new Resouce("Answer not found for this id "+answerId));
		ans.setQuestion(answer.getQuestion());
		ans.setDescription(answer.getDescription());
		return answerRepository.save(ans);
	}
	@DeleteMapping("/question/{questionId}/answer/{answerId}")
	public ResponseEntity<Answer> deleteAnswerById(@PathVariable(value="questionId") Long questionId,@PathVariable(value="answerId") Long answerId) throws Resouce{
		if(!questionRepository.existsById(questionId))
			 throw new Resouce("Questoin not found for this id "+questionId);
		Answer a=answerRepository.findById(answerId).orElseThrow(()-> new Resouce("Answer not found for this id "+ answerId));
		
		answerRepository.delete(a);
		
		return ResponseEntity.ok().body(a);
	}
}
