package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Answer;
import com.example.demo.repository.AnswerRepository;

@RestController
public class AnswerController {
	@Autowired
	private AnswerRepository answerRepository;
	@GetMapping("/home")
	public String home() {
		return "Welcome Buddy!";
	}
	@GetMapping("/answers")
	public List<Answer> getAllAnswers(){
		return answerRepository.findAll();
	}
	@GetMapping("/answer/{answerId}")
	public ResponseEntity<Answer> getAnswerById(@PathVariable(value="answerId") Long answerId) throws ResourceNotFoundException{
		Answer answer=answerRepository.findById(answerId).orElseThrow(()->new ResourceNotFoundException("Answer not found for this id "+answerId));
		return ResponseEntity.ok().body(answer);
	}
	@PostMapping("/answer")
	public Answer createAnswer(@RequestBody Answer answer) {
		return answerRepository.save(answer);
	}
	@PutMapping("/answer/{answerId}")
	public ResponseEntity<Answer> updateAnswerById(@PathVariable(value="answerId") Long answerId,Answer answerDetails) throws ResourceNotFoundException{
		Answer answer=answerRepository.findById(answerId).orElseThrow(()-> new ResourceNotFoundException("Answer not found for this id "+answerId));
		answer.setDescription(answerDetails.getDescription());
		answer.setText(answerDetails.getText());
		answerRepository.save(answer);
		return ResponseEntity.ok().body(answer);
	}
	@DeleteMapping("/answer/{answerId}")
	public Map<String,Boolean> deleteAnswer(@PathVariable(value="answerId") Long answerId) throws ResourceNotFoundException{
		Answer answer=answerRepository.findById(answerId).orElseThrow(()->new ResourceNotFoundException("Answer not found for this id "+answerId));
		answerRepository.delete(answer);
		Map<String, Boolean> response=new HashMap();
		response.put("deleted", true);
		return response;
	}

}
