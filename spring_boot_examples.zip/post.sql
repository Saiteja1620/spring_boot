create table employee(emp_id integer not null primary key,emp_name varchar(40),department varchar(40));
insert into employee
values
(3,'sairam','analytics'),
(4,'vikram','dbms');
select * from employee;
alter table employee add column salary integer;
update employee set salary=12500 where emp_id =4;
select sum(salary) as total_salary from employee;
select avg(salary) as avg_salary from employee;
select count(emp_id) as total_emp from employee;
insert into employee values(5,'veneeth','sales');
update employee set salary=10000 where emp_name='veneeth';
select distinct salary from employee;
select * from employee order by salary desc;
select * from employee order by salary;
select * from employee where salary in (10000,50000) order by salary desc;
select * from employee where salary between 10000 and 50000 order by salary desc;
select * from employee where salary>10000 and salary<50000;
select department, sum(salary) as sum_salary from employee group by department;
select * from employee where emp_name like '%a';
select * from employee where emp_name like '_a%';
select department from employee group by department;
select distinct salary from employee;
select * from employee order by salary limit 3;
select * from employee order by salary desc limit 3;
select department, sum(salary) from employee group by department;
select * from employee order by salary desc fetch first 3 rows only;
drop table student;
create table department(emp_id int,department_no int);
insert into department values(1,101),
(2,102),
(3,103),
(4,104),
(5,105);
select * from employee,department;
create table basket_a(a int ,fruit_a varchar(10));
insert into basket_a values
	(1, 'Apple'),
    (2, 'Orange'),
    (3, 'Banana'),
    (4, 'Cucumber');
create table basket_b(b int, fruit_b varchar(10));
insert into basket_b values
(1, 'Orange'),
    (2, 'Apple'),
    (3, 'Watermelon'),
    (4, 'Pear');
/*inner join*/
--method 1
select * from basket_a inner join basket_b on fruit_a = fruit_b;
--method 2
select * from basket_a, basket_b where fruit_a = fruit_b;
--full join
select * from basket_a, basket_b;
--full outer join
select * from basket_a full outer join basket_b on fruit_a=fruit_b;
--right join
select * from basket_a right join basket_b on fruit_a =fruit_b;
--left join
select * from basket_a left join basket_b on fruit_a = fruit_b;
--left outer join 
select * from basket_a left outer join basket_b on fruit_a=fruit_b;
select * from basket_a left outer join basket_b on fruit_a=fruit_b where b is not null;
drop table employee;
drop table department;
create table employee(emp_id int not null primary key,emp_name varchar(10));
insert into employee values(1,'sai'),
(2,'teja'),
(3,'sairam'),
(4,'mukund'),
(5,'veneeth'),
(6,'nikhil'),
(7,'vikram');
select * from employee;
create table department(emp_id int,foreign key(emp_id) references employee(emp_id),department_name varchar(10));
insert into department values (1,'cse'),
(2,'ece'),
(3,'eee'),
(4,'cse'),
(5,'mech'),
(6,'ece'),
(7,'civil');
select emp_name,department_name from employee join department on department.emp_id=employee.emp_id;
select distinct department_name from department;
select department_name,count(emp_id) as total_emp from department group by department_name;